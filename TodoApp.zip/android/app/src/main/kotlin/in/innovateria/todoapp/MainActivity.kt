package `in`.innovateria.todoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
